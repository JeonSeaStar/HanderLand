using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Ride_State : MonoBehaviour
{
    public bool Place_Check = false;
    public string Name_Original, Name_this;
    public float Price, Intensity, interest, Sickness_rate;
    public bool Research_Status, IsEntrance, IsExit;
    public GameObject Entrance, Exit;
    public Texture Image;
    public Camera Camera;
    public List<Vector3> EntExitPosition;

    void Start()
    {

    }

    void Update()
    {

    }

    void IsEntranceNExit()
    {
        if(Entrance == null) { IsEntrance = false; }
        else { IsEntrance = true; }
        if(Exit == null) { IsExit = false; }
        else { IsExit = true; }
    }

    public void Ride_Position()
    {
        if (Place_Check == false)
        {
            Ray ray = Camera.main.ScreenPointToRay(Input.mousePosition);
            RaycastHit hit;
            Physics.Raycast(ray, out hit);
            Debug.Log("���� �������� ������Ʈ �̸�" + hit.collider.gameObject.name + "���� �������� ���� ��ġ: " + hit.collider.gameObject.transform.position.x + ", " + hit.collider.gameObject.transform.position.y + ", " + hit.collider.gameObject.transform.position.z);
            this.gameObject.transform.position = new Vector3(Mathf.Round(hit.collider.gameObject.transform.position.x), Mathf.Round(hit.collider.gameObject.transform.position.y) + hit.collider.gameObject.transform.localScale.y / 2, Mathf.Round(hit.collider.gameObject.transform.position.z));
        }
        else if (Place_Check == true)
        {
            this.gameObject.transform.position = this.gameObject.transform.position;
        }

        if (Input.GetMouseButtonDown(0))
        {
            Place_Check = true;
        }
    }
}
