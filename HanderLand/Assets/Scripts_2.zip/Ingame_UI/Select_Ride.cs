using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class Select_Ride : MonoBehaviour
{
    public TextMeshProUGUI ride_name, ride_state, ride_CameraView, ride_text_interest, ride_text_intensity, ride_text_sick, ride_text_money, ride_text_money_total, ride_text_money_perHour, ride_text_modelyear, ride_text_peaple_total, ride_text_peaple_perHour, ride_text_peaple_current;
    public float ride_interest, ride_intensity, ride_sick, ride_money, ride_money_total, ride_money_perHour;
    public int ride_inspection, ride_modelyear, ride_peaple_total, ride_peaple_perHour, ride_peaple_current;
    void Start()
    {
        
    }

    void Update()
    {
        
    }
}
