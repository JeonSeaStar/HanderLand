using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;

public class GameManager : MonoBehaviour
{
    public GameObject Ground;
    public GameObject guest;
    public GameObject Rename_Popup;
    public GameObject Ride_Select_Popup;
    public int Guest_Num = 0;
    public int x, z;
    public static bool Ground_EditMode = false;
    public GameObject[] Guest_Select_Popup = new GameObject[6];
    public GameObject[] Select_Guest = new GameObject[6];
    public bool[] Guest_Select = new bool[6];
    Vector3 Click_MousePos, MousePos;
    RaycastHit hit;
    public int Camera_Mode = 0;
    public GameObject[] Camera_Tracking;
    public float Camera_Speed;
    public GameObject[] Base_Point;
    public Camera Camera_Main;
    public TextMeshProUGUI Park_Name_text, Park_Grade_text, Park_Guest_text, Park_Money_text, Park_Date_text, Park_Time_text, Park_Temperature_text;
    public string Park_Name, Park_Date, Park_Time;
    public int Park_Grade, Park_Guest,Park_Date_Year, Park_Date_Month, Park_Date_Day, Park_Temperature;
    public float Park_Money, Park_Time_Hour, Park_Time_Min;

    public List<GameObject> Target;

    void Start()
    {
        Physics.IgnoreLayerCollision(9, 11);
        Ground_Spawn(x, z);
    }

    void Update()
    {
        Select();
        Camera_Position();
    }

    void Ground_Spawn(int x, int z) // ������ ������ x�� ����, y�� ���� z�� ����
    {
        Vector3 Ground_Pos = new Vector3(0, 0, 0);
        for (int i = 0; i < x; i++)
        {
            for (int j = 0; j < z; j++)
            {
                Ground = Instantiate(Ground, Ground_Pos, Quaternion.identity);
                Ground.name = ("Ground[" + i + ", " + j + "]");
                Ground.transform.parent = this.transform;

                Ground_Pos.z++; //������ z ũ�⸸ŭ
            }
            Ground_Pos.z = 0;
            Ground_Pos.x++; //������ x ũ�⸸ŭ
        }
    }

    public void guest_spawn()
    {
        Debug.Log("�մ� ��ȯ !");
        guest = Instantiate(guest, new Vector3(0, 0.45f, 0), Quaternion.identity);
        guest.name = ("Guest[" + Guest_Num + "]");
        guest.GetComponent<Guest>().speed = Random.Range(1, 6);
        Guest_Num += 1;
    }

    public void Ground_Edit()
    {
        if(Ground_EditMode == false)
        {
            Ground_EditMode = true;
            Debug.Log("���� ������� ON");
        }
        else if(Ground_EditMode == true)
        {
            Ground_EditMode = false;
            Debug.Log("���� ������� OFF");
        }
    }

    void Select()
    {
        if (Input.GetMouseButtonDown(0))
        {
            Click_MousePos = Input.mousePosition;
            Ray ray = Camera.main.ScreenPointToRay(Input.mousePosition);
            Physics.Raycast(ray, out hit, 1<<9);

            if(hit.collider != null)
            {
                if (hit.collider.gameObject.layer == LayerMask.NameToLayer("guest"))
                {
                    for (int i = 0; i < 6; i++)
                    {
                        if (Guest_Select[i] == false)
                        {
                            Guest_Select[i] = true;
                            Select_Guest[i] = hit.collider.gameObject;
                            Guest_Select_Popup[i].gameObject.SetActive(true);
                            break;
                        }
                        else { continue; }
                    }
                    Debug.Log(hit.collider.gameObject.name);
                }
            }
        }
    }

    void Camera_Position()
    {
        Base_Point[1].transform.position = Base_Point[0].transform.position;

        if (Rename_Popup.activeSelf == false)
        {
            switch (Camera_Mode)
            {
                case 0:
                    if (Input.GetKeyDown(KeyCode.Q))
                    {
                        Camera_Mode = 1;
                    }
                    else if (Input.GetKeyDown(KeyCode.E))
                    {
                        Camera_Mode = 3;
                    }

                    Base_Point[1].transform.eulerAngles = new Vector3(45, 315, 0);

                    for (int i = 0; i < 6; i++)

                    {
                        if (Select_Guest[i] != null)
                        {
                            Camera_Tracking[i].transform.position = new Vector3(Select_Guest[i].transform.position.x + 1.5f, Select_Guest[i].transform.position.y + 2.5f, Select_Guest[i].transform.position.z - 1.5f);
                            Camera_Tracking[i].transform.eulerAngles = new Vector3(45, 315, 0);
                        }
                    }

                    if (Input.GetKey(KeyCode.W))
                    {
                        Base_Point[0].transform.Translate(Vector3.forward * Camera_Speed * Time.deltaTime);
                        Base_Point[0].transform.Translate(Vector3.left * Camera_Speed * Time.deltaTime);
                    }
                    if (Input.GetKey(KeyCode.A))
                    {
                        Base_Point[0].transform.Translate(Vector3.left * Camera_Speed * Time.deltaTime);
                        Base_Point[0].transform.Translate(Vector3.back * Camera_Speed * Time.deltaTime);
                    }
                    if (Input.GetKey(KeyCode.S))
                    {
                        Base_Point[0].transform.Translate(Vector3.back * Camera_Speed * Time.deltaTime);
                        Base_Point[0].transform.Translate(Vector3.right * Camera_Speed * Time.deltaTime);
                    }
                    if (Input.GetKey(KeyCode.D))
                    {
                        Base_Point[0].transform.Translate(Vector3.right * Camera_Speed * Time.deltaTime);
                        Base_Point[0].transform.Translate(Vector3.forward * Camera_Speed * Time.deltaTime);
                    }
                    break;
                case 1:
                    if (Input.GetKeyDown(KeyCode.Q))
                    {
                        Camera_Mode = 2;
                    }
                    else if (Input.GetKeyDown(KeyCode.E))
                    {
                        Camera_Mode = 0;
                    }

                    Base_Point[1].transform.eulerAngles = new Vector3(45, 45, 0);

                    for (int i = 0; i < 6; i++)
                    {
                        if (Select_Guest[i] != null)
                        {
                            Camera_Tracking[i].transform.position = new Vector3(Select_Guest[i].transform.position.x - 1.5f, Select_Guest[i].transform.position.y + 2.5f, Select_Guest[i].transform.position.z - 1.5f);
                            Camera_Tracking[i].transform.eulerAngles = new Vector3(45, 45, 0);
                        }
                    }

                    if (Input.GetKey(KeyCode.W))
                    {
                        Base_Point[0].transform.Translate(Vector3.right * Camera_Speed * Time.deltaTime);
                        Base_Point[0].transform.Translate(Vector3.forward * Camera_Speed * Time.deltaTime);
                    }
                    if (Input.GetKey(KeyCode.A))
                    {
                        Base_Point[0].transform.Translate(Vector3.forward * Camera_Speed * Time.deltaTime);
                        Base_Point[0].transform.Translate(Vector3.left * Camera_Speed * Time.deltaTime);
                    }
                    if (Input.GetKey(KeyCode.S))
                    {
                        Base_Point[0].transform.Translate(Vector3.left * Camera_Speed * Time.deltaTime);
                        Base_Point[0].transform.Translate(Vector3.back * Camera_Speed * Time.deltaTime);
                    }
                    if (Input.GetKey(KeyCode.D))
                    {
                        Base_Point[0].transform.Translate(Vector3.back * Camera_Speed * Time.deltaTime);
                        Base_Point[0].transform.Translate(Vector3.right * Camera_Speed * Time.deltaTime);
                    }
                    break;
                case 2:
                    if (Input.GetKeyDown(KeyCode.Q))
                    {
                        Camera_Mode = 3;
                    }
                    else if (Input.GetKeyDown(KeyCode.E))
                    {
                        Camera_Mode = 1;
                    }

                    Base_Point[1].transform.eulerAngles = new Vector3(45, 135, 0);

                    for (int i = 0; i < 6; i++)
                    {
                        if (Select_Guest[i] != null)
                        {
                            Camera_Tracking[i].transform.position = new Vector3(Select_Guest[i].transform.position.x - 1.5f, Select_Guest[i].transform.position.y + 2.5f, Select_Guest[i].transform.position.z + 1.5f);
                            Camera_Tracking[i].transform.eulerAngles = new Vector3(45, 135, 0);
                        }
                    }

                    if (Input.GetKey(KeyCode.W))
                    {
                        Base_Point[0].transform.Translate(Vector3.back * Camera_Speed * Time.deltaTime);
                        Base_Point[0].transform.Translate(Vector3.right * Camera_Speed * Time.deltaTime);
                    }
                    if (Input.GetKey(KeyCode.A))
                    {
                        Base_Point[0].transform.Translate(Vector3.right * Camera_Speed * Time.deltaTime);
                        Base_Point[0].transform.Translate(Vector3.forward * Camera_Speed * Time.deltaTime);
                    }
                    if (Input.GetKey(KeyCode.S))
                    {
                        Base_Point[0].transform.Translate(Vector3.forward * Camera_Speed * Time.deltaTime);
                        Base_Point[0].transform.Translate(Vector3.left * Camera_Speed * Time.deltaTime);
                    }
                    if (Input.GetKey(KeyCode.D))
                    {
                        Base_Point[0].transform.Translate(Vector3.left * Camera_Speed * Time.deltaTime);
                        Base_Point[0].transform.Translate(Vector3.back * Camera_Speed * Time.deltaTime);
                    }
                    break;
                case 3:
                    if (Input.GetKeyDown(KeyCode.Q))
                    {
                        Camera_Mode = 0;
                    }
                    else if (Input.GetKeyDown(KeyCode.E))
                    {
                        Camera_Mode = 2;
                    }

                    Base_Point[1].transform.eulerAngles = new Vector3(45, 225, 0);

                    for (int i = 0; i < 6; i++)
                    {
                        if (Select_Guest[i] != null)
                        {
                            Camera_Tracking[i].transform.position = new Vector3(Select_Guest[i].transform.position.x + 1.5f, Select_Guest[i].transform.position.y + 2.5f, Select_Guest[i].transform.position.z + 1.5f);
                            Camera_Tracking[i].transform.eulerAngles = new Vector3(45, 225, 0);
                        }
                    }

                    if (Input.GetKey(KeyCode.W))
                    {
                        Base_Point[0].transform.Translate(Vector3.left * Camera_Speed * Time.deltaTime);
                        Base_Point[0].transform.Translate(Vector3.back * Camera_Speed * Time.deltaTime);
                    }
                    if (Input.GetKey(KeyCode.A))
                    {
                        Base_Point[0].transform.Translate(Vector3.back * Camera_Speed * Time.deltaTime);
                        Base_Point[0].transform.Translate(Vector3.right * Camera_Speed * Time.deltaTime);
                    }
                    if (Input.GetKey(KeyCode.S))
                    {
                        Base_Point[0].transform.Translate(Vector3.right * Camera_Speed * Time.deltaTime);
                        Base_Point[0].transform.Translate(Vector3.forward * Camera_Speed * Time.deltaTime);
                    }
                    if (Input.GetKey(KeyCode.D))
                    {
                        Base_Point[0].transform.Translate(Vector3.forward * Camera_Speed * Time.deltaTime);
                        Base_Point[0].transform.Translate(Vector3.left * Camera_Speed * Time.deltaTime);
                    }
                    break;
            }
        }
    }

    void Park_State()
    {
        

    }

    public void Open_Rides_Select()
    {
        Ride_Select_Popup.SetActive(true);
    }
}
