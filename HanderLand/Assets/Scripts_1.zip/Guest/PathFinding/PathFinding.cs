using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PathFinding : MonoBehaviour
{
    public GameObject TargetNode_;
    public List<Node> FinalPath;

    void Start()
    {
        
    }

    void Update()
    {

    }

    public void pathfinding(Node StartNode, Node TargetNode)
    {
        Node CurrentNode = StartNode;
        List<Node> Neighbor = new List<Node>();
        FinalPath = new List<Node>();
        DeleteParents();
        while (CurrentNode != TargetNode)
        {
            Neighbor = NeighborNode(CurrentNode);
            for (int i = 0; i < Neighbor.Count; i++)
            {
                if (Neighbor[i] == CurrentNode.ParentNode)
                {
                    Neighbor.Remove(Neighbor[i]);
                    i = 0;
                }
                else if (Neighbor[i].IsRoad == true)
                {
                    Neighbor[i].gCost = ManhattanDistance(Neighbor[i], CurrentNode);
                    Neighbor[i].hCost = ManhattanDistance(Neighbor[i], TargetNode);
                }
            }

            Node LowFCost_Neighbor = null;

            if(Neighbor.Count == 0)
                break;

            if (Neighbor[0].IsRoad)
                LowFCost_Neighbor = Neighbor[0];

            if (Neighbor.Count == 1)
            {
                LowFCost_Neighbor.ParentNode = CurrentNode;
                CurrentNode = LowFCost_Neighbor;
                FinalPath.Add(CurrentNode);
            }
            else if (Neighbor.Count > 1)
            {
                for (int i = 0; i < Neighbor.Count; i++)
                {
                    if(LowFCost_Neighbor.fCost > Neighbor[i].fCost)
                    {
                        LowFCost_Neighbor = Neighbor[i];
                    }
                }
                LowFCost_Neighbor.ParentNode = CurrentNode;
                CurrentNode = LowFCost_Neighbor;
                FinalPath.Add(CurrentNode);
            }
            UpdateFinalPath();
        }
    }

    public Node posStart(GameObject gameObject)
    {
        Vector3 PosStart = new Vector3(Mathf.Round(gameObject.transform.position.x), (gameObject.transform.position.y - 0.45f) / 0.5f, Mathf.Round(gameObject.transform.position.z));
        int x = (int)PosStart.x;
        int y = (int)PosStart.y + 1;
        int z = (int)PosStart.z;
        Node NodeStart = this.GetComponent<Grids>().GridList[y][x, z];

        return NodeStart;
    }

    public Node posTarget(GameObject gameObject)
    {
        Vector3 PosTarget = new Vector3(Mathf.Round(gameObject.transform.position.x), gameObject.transform.position.y, Mathf.Round(gameObject.transform.position.z));
        float xx = 0.25f * gameObject.transform.localScale.y;
        PosTarget.y = xx / 0.25f * 0.25f;
        int x = (int)PosTarget.x;
        int y = (int)PosTarget.y + 1;
        int z = (int)PosTarget.z;
        Node NodeTarget = this.GetComponent<Grids>().GridList[y][x, z];
        
        return NodeTarget;
    }
    
    public List<Node> NeighborNode(Node Current)
    {
        List<Node> Neighbor = new List<Node>();
        Node LeftNode, RightNode, ForwardNode, BackNode;
        int x;
        float yy = Current.NodePosition.y * 2;
        int y = (int)yy;
        int z;

        x = (int)Current.NodePosition.x + 1;
        z = (int)Current.NodePosition.z;
        if(x + z < GetComponent<Grids>().GridList[y].Length && x >= 0)
        {
            LeftNode = this.GetComponent<Grids>().GridList[y][x, z];
            if(LeftNode.IsRoad == true)
            {
                Neighbor.Add(LeftNode);
            }
        }

        x = (int)Current.NodePosition.x - 1;
        z = (int)Current.NodePosition.z;
        if (x + z < GetComponent<Grids>().GridList[y].Length && x >= 0)
        {
            RightNode = this.GetComponent<Grids>().GridList[y][x, z];
            if (RightNode.IsRoad == true)
            {
                Neighbor.Add(RightNode);
            }
        }

        x = (int)Current.NodePosition.x;
        z = (int)Current.NodePosition.z + 1;
        if (x + z < GetComponent<Grids>().GridList[y].Length && z >= 0)
        {
            ForwardNode = this.GetComponent<Grids>().GridList[y][x, z];
            if (ForwardNode.IsRoad == true)
            {
                Neighbor.Add(ForwardNode);
            }
        }

        x = (int)Current.NodePosition.x;
        z = (int)Current.NodePosition.z - 1;
        if (x + z < GetComponent<Grids>().GridList[y].Length && z >= 0)
        {
            BackNode = this.GetComponent<Grids>().GridList[y][x, z];
            if (BackNode.IsRoad == true)
            {
                Neighbor.Add(BackNode);
            }
        }

        return Neighbor;
    }

    void UpdateFinalPath()
    {
        this.GetComponent<Grids>().FinalPath = FinalPath;
        this.GetComponent<Guest>().Path = FinalPath;
    }

    void DeleteParents()
    {
        int worldX = this.transform.GetComponent<Grids>().worldX;
        int worldY = this.transform.GetComponent<Grids>().worldY;
        int worldZ = this.transform.GetComponent<Grids>().worldZ;
        for (int y = 0; y < worldY; y++)
        {
            for (int x = 0; x < worldX; x++)
            {
                for (int z = 0; z < worldZ; z++)
                {
                    this.transform.GetComponent<Grids>().GridList[y][x, z].ParentNode = null;
                }
            }
        }
    }

    int ManhattanDistance(Node Current, Node Target)
    {
        int x = Mathf.Abs(Current.GridX - Target.GridX);
        int z = Mathf.Abs(Current.GridZ - Target.GridZ);

        return x + z;
    }
}
