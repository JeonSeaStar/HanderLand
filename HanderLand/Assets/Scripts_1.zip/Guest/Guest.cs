using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Guest : MonoBehaviour
{
    public List<Behavior> behaviors = new List<Behavior>();
    public int total = 0;
    public Behavior behavior;
    public List<Node> Path;
    PathFinding pf;
    public GameObject gm;
    public bool IsFindPath;

    public float speed;
    public int direction;
    public string Guest_Name, Guest_Think, Guest_Behavior;
    public float Gauge_Happy_Max, Gauge_Happy, Gauge_Energy_Max, Gauge_Energy, Gauge_Hungry_Max, Gauge_Hungry, Gauge_Thirst_Max, Gauge_Thirst, Gauge_Sick_Max, Gauge_Sick, Gauge_Toilet_Max, Gauge_Toilet, Gauge_Intensity, Gauge_Tolerance;
    public int Record_Ride, Record_Food, Record_Drink, Record_Souvenir;
    public float TimeRecord, Money_InHand, Money_Spent, Money_AdmissionFees, Money_Ride, Money_FoodNDrink, Money_Souvenir;

    void Start()
    {
        Physics.IgnoreLayerCollision(9, 9);
        gm = GameObject.Find("GameManager");
        pf = this.transform.GetComponent<PathFinding>();
        this.transform.GetComponent<Grids>().CreateGrid();
        decide_target();
    }

    void Update()
    {
        decide_Behavior();
    }

    public Behavior Next_Behavior()
    {
        int weight = 0;
        int selectNum = 0;
        total = 0;
        for (int i = 0; i < behaviors.Count; i++)
        {
            total += behaviors[i].weight;
        }

        selectNum = Mathf.RoundToInt(total * Random.Range(0.0f, 1.0f));

        for(int i = 0; i < behaviors.Count; i++)
        {
            weight += behaviors[i].weight;
            if(selectNum <= weight)
            {
                behavior = new Behavior(behaviors[i]);
                return behavior;
            }
        }
        return null;
    }

    void decide_Behavior()
    {
        switch (behavior.Behavior_name)
        {
            case "Move":
                Move();
                break;

            case "Navigater":
                Navigater();
                break;

            case "Leave":
                Leave();
                break;

            case "Stay":
                Stay();
                break;

            case "Board_Ride":
                Board_Ride();
                break;

            case "GoToSeat":
                GoToSeat();
                break;

            case "GoToExit":
                GoToExit();
                break;

            case "Use_Shop":
                Use_Shop();
                break;

            case "SightSeeing_Ride":
                SightSeeing_Ride();
                break;

            case "TakePicture_Ride":
                TakePicture_Ride();
                break;

            case "ThrowUp":
                ThrowUp();
                break;
        }
    }

    void decide_target()
    {
        int i = Random.Range(0, gm.transform.GetComponent<GameManager>().Target.Count);
        IsFindPath = true;
        this.transform.GetComponent<PathFinding>().TargetNode_ = gm.transform.GetComponent<GameManager>().Target[i];
        pf.pathfinding(pf.posStart(this.gameObject), pf.posTarget(pf.TargetNode_));
    }

    void Move()
    {
        if (this.transform.GetComponent<PathFinding>().TargetNode_ == null)
        {
            decide_target();
        }
        else if (this.transform.GetComponent<PathFinding>().TargetNode_ != null)
        {
            if (Path.Count != 0)
            {
                IsFindPath = true;

                transform.position = Vector3.MoveTowards(this.transform.position, new Vector3(Path[0].NodePosition.x, this.transform.position.y, Path[0].NodePosition.z), Time.deltaTime * speed);
                if (this.transform.position == new Vector3(Path[0].NodePosition.x, this.transform.position.y, Path[0].NodePosition.z))
                {
                    Path.Remove(Path[0]);
                }
            }
            else if (Path.Count == 0)
            {
                IsFindPath = false;

                if (IsFindPath == false && this.transform.position != new Vector3(pf.TargetNode_.transform.position.x, this.transform.position.y, pf.TargetNode_.transform.position.z))
                {
                    pf.pathfinding(pf.posStart(this.gameObject), pf.posTarget(pf.TargetNode_));
                }
                if (IsFindPath == false && this.transform.position == new Vector3(pf.TargetNode_.transform.position.x, this.transform.position.y, pf.TargetNode_.transform.position.z))
                {
                    pf.TargetNode_ = null;
                    decide_target();
                }
            }
        }
    }

    void Navigater()
    {

    }

    void Leave()
    {

    }

    void Stay()
    {

    }

    void Board_Ride()
    {

    }

    void GoToSeat()
    {

    }

    void GoToExit()
    {

    }

    void Use_Shop()
    {

    }

    void SightSeeing_Ride()
    {

    }

    void TakePicture_Ride()
    {

    }

    void ThrowUp()
    {

    }

    void Emotion()
    {
        Gauge_Energy -= 1;
    }
}
